const bodyParser = require("body-parser")
const express = require("express")
const cors = require("cors")
const Port = process.env.PORT || 7000
require("./dbconnection")

const app = express()

app.use(cors())
app.use(bodyParser.json())
app.use("/api/report", require("./report"))

app.get("/",(req,res)=>{
    console.log("........", req.ip)
})

app.listen(Port,()=>{
    console.log(`Server is listening on ${Port}`)
})