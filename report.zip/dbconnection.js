var mongoose = require("mongoose")

const dburl = "mongodb://127.0.0.1/demoappdb"

mongoose.connect(dburl).then(()=>{
    console.log("Database connection")
}).catch((error)=>{
    console.log("Error Connecting to Database", error)
})

